import 'package:todo_starter/models/task_model.dart';

class AppBrain {

  final List<TaskModel> tasks = [];

}