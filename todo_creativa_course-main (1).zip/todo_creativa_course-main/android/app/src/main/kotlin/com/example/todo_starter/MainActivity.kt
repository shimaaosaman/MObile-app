package com.example.todo_starter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
